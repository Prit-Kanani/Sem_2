//Calculate the square of integers 1 through 10.
#include<stdio.h>
void main() {
 int i=1;
 while(i<=10) 
{
printf("%i\n",i*i);
i++;
}
}


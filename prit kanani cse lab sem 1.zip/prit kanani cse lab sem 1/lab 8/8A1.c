#include<stdio.h>
void main () {
	float a,i=0;
	while(i<=9)
	{
		printf("%f\n",sqrt(i));
		i++;
	}
}

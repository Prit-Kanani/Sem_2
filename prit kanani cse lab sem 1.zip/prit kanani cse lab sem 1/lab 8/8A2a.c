#include<stdio.h>
void main() {
	int i=1,n=10;
	while(i<=10)
	{
		printf("%d",i);
		i=i+2;
	}
}

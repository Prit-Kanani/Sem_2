#include<stdio.h>
void main() {
	int i=1,n;
	scanf("%d",&n)
	while(i<=10)
	{
		printf("%d",i);
		i=i+2;
	}
}

#include<stdio.h>
void main(){
	int a,i=1,sum=0;
	scanf("%d",&a);
	for(i=1;i<=a;i++){
		sum=sum+i;
	}
	printf("%d",sum);
}

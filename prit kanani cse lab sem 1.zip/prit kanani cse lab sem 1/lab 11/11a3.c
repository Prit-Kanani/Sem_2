#include<stdio.h>
void main(){
	int a,i=1;
	scanf("%d",&a);
	for(i=1;i<=10;i++){
		printf("%d x %d = %d\n",a,i,a*i );
	}
	
}

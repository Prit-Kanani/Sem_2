#include<stdio.h>
void main() {
	int a,b,c;
	printf("Enter Value :");
    scanf("%d",&a);
    b=(a%2==0)?printf("Number Is Even"):printf("Number Is Odd");
}

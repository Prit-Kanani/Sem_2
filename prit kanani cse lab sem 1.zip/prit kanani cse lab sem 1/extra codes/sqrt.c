#include<stdio.h>
#include<math.h>
void main(){

	int x = 5*9/3+9;
	printf("%d",x);
	
}


	

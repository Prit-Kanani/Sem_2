#include<stdio.h>

void main() {

int a = 10;
int b = 20;
int c = a + b;
printf("addition of number is :%d", c);

}
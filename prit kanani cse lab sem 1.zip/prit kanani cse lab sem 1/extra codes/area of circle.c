#include<stdio.h>
void main(){
	int r,A;
	printf("Enter r:");
	scanf("%d",&r);
	A=3.14*r*r;
	printf("Area=%d",A);
}

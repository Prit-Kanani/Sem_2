# include<stdio.h>

//write a programme to check if a number is divisible by 2 or not

int main() {
      int x;
      printf("enter number:");
      scanf("%d", &x);
      printf("%d \n" , x % 2 == 0);
      return 0;
}    

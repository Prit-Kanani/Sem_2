#include<stdio.h>
void main(){
	int a,b,c,d;
	printf("Enter V1:");
	scanf("%d",&a);
	printf("Enter V2:");
	scanf("%d",&b);
	printf("Enter V3:");
	scanf("%d",&c);
	d=(a+b+c)/3;
	printf("Avg=%d",d);
}

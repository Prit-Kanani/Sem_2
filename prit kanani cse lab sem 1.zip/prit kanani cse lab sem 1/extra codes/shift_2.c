#include<stdio.h>

void main() {

    int n;
    printf("enter a number:");
    scanf("%d", &n);
    n=n<<1;
    printf("%d", n);
    
}
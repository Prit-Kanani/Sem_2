#include<stdio.h>
void main(){
	int a,b,c,d;
	printf("Enter V1 and V2:");
	scanf("%d %d",&a,&b);
	c=a+b;
	printf("Avg=%d",c);
}

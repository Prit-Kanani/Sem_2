# include<stdio.h>

//modulo

int main() {
      printf("%d \n", 16 % 10 );
      return 0;
}    

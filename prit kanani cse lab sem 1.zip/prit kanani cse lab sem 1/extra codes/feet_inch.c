#include<stdio.h>

int main() {

float feet;
float inch;

printf("enter feet:");
scanf("%f", &feet);

inch = 12 * feet;
printf("inch : %f", inch);

}

#include<stdio.h>

void main() {

int a = 2, b = 3, c = 4;
float d = (a + b + c)/(float)3;
printf("average of 3 numbers is %f", d);

}
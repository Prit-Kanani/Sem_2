#include<stdio.h>
void main(){
	int feet,inch;
	printf("enter, feet");
	scanf("%d",&feet);
	inch=12*feet;
	printf("inch%d",inch);
}

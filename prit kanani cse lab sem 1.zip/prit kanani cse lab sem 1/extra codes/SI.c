#include<stdio.h>
void main(){
	int T,R,P,SI;
	printf("Enter V1:");
	scanf("%d",&P);
	printf("Enter V2:");
	scanf("%d",&R);
	printf("Enter V2:");
	scanf("%d",&T);
	SI=(P*R*T)/100;
	printf("Simple Intrest=%d",SI);
}


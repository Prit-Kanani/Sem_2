#include<stdio.h>

void main() {

int a,b,c;
printf("enter 2 numbers:");
scanf("%d %d", &a, &b);
c = a + b;
printf("addition of number is :%d", c);

}
#include<stdio.h>
void main(){
	int a,b,c;
	printf("Enter V1:");
	scanf("%d",&a);
	printf("Enter V2:");
	scanf("%d",&b);
	c=a+b;
	printf("Sum=%d",c);
}

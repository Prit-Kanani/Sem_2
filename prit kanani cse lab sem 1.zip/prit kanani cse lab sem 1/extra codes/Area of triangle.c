#include<stdio.h>
void main(){
	int A,b,h;
	printf("Enter V1:");
	scanf("%d",&b);
	printf("Enter V2:");
	scanf("%d",&h);
	A=(b*h)/2;
	printf("Area=%d",A);
}

#include<stdio.h>
void main()
{ float f,I;
printf("Enter value in feet:");
scanf("%f",&f);
I=f/12;
printf("Inches=%f",I);
}
